"""Core infrastructure layer for RIKI RPG."""
